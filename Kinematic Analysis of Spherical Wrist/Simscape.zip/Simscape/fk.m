function varargout = fk(varargin)
% FK MATLAB code for fk.fig
%      FK, by itself, creates a new FK or raises the existing
%      singleton*.
%
%      H = FK returns the handle to a new FK or the handle to
%      the existing singleton*.
%
%      FK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FK.M with the given input arguments.
%
%      FK('Property','Value',...) creates a new FK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fk_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fk_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fk

% Last Modified by GUIDE v2.5 23-Nov-2016 17:58:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fk_OpeningFcn, ...
                   'gui_OutputFcn',  @fk_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fk is made visible.
function fk_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fk (see VARARGIN)

% Choose default command line output for fk
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fk wait for user response (see UIRESUME)
% uiwait(handles.figure1);
% set both matrices to identity matrix
rotmatrix = [1 0 0 ; 0 1 0 ; 0 0 1];
set(handles.transmatrix,'data',rotmatrix);
set(handles.rotmatrix1,'data',rotmatrix);

% --- Outputs from this function are returned to the command line.
function varargout = fk_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in rotorder.
function rotorder_Callback(hObject, eventdata, handles)
% hObject    handle to rotorder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns rotorder contents as cell array
%        contents{get(hObject,'Value')} returns selected item from rotorder


% --- Executes during object creation, after setting all properties.
function rotorder_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rotorder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function j1_Callback(hObject, eventdata, handles)
% hObject    handle to j1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j1 as text
%        str2double(get(hObject,'String')) returns contents of j1 as a double


% --- Executes during object creation, after setting all properties.
function j1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function j2_Callback(hObject, eventdata, handles)
% hObject    handle to j2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j2 as text
%        str2double(get(hObject,'String')) returns contents of j2 as a double


% --- Executes during object creation, after setting all properties.
function j2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function j3_Callback(hObject, eventdata, handles)
% hObject    handle to j3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j3 as text
%        str2double(get(hObject,'String')) returns contents of j3 as a double


% --- Executes during object creation, after setting all properties.
function j3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in createtransmatrix.
function createtransmatrix_Callback(hObject, eventdata, handles)
% hObject    handle to createtransmatrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% get joint angles from user input
j1 = str2double(get(handles.j1,'string'));
j2 = str2double(get(handles.j2,'string'));
j3 = str2double(get(handles.j3,'string'));
% evaluate transformation matrix
transmatrix = evaltransmatrix(j1,j2,j3);
% display transformation matrix
set(handles.transmatrix,'data',transmatrix);
% display result of operation
set(handles.rotmatrixresult,'string','Transformation matrix created!');

% --- Executes on button press in clear.
function clear_Callback(hObject, eventdata, handles)
% hObject    handle to clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% makes all input zero
set(handles.j1,'string','0');
set(handles.j2,'string','0');
set(handles.j3,'string','0');
transmatrix = [1 0 0 ; 0 1 0 ; 0 0 1];
set(handles.transmatrix,'data',transmatrix);

% --- Executes on button press in simulate.
function simulate_Callback(hObject, eventdata, handles)
% hObject    handle to simulate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% get joint angles from user input
j1 = get(handles.j1,'string');
j2 = get(handles.j2,'string');
j3 = get(handles.j3,'string');
% get joint velocities from user input
j1vel = get(handles.j1vel,'string');
j2vel = get(handles.j2vel,'string');
j3vel = get(handles.j3vel,'string');
% execute simulation
execute(j1,j2,j3,j1vel,j2vel,j3vel);
guidata(hObject,handles);

% --- Executes on button press in compute.
function compute_Callback(hObject, eventdata, handles)
% hObject    handle to compute (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
j1 = str2double(get(handles.j1,'string'));
j2 = str2double(get(handles.j2,'string'));
j3 = str2double(get(handles.j3,'string'));
rotorder = num2str(get(handles.rotorder,'value'));
rotmatrix = evaltransmatrix(j1,j2,j3);
[x,y,z] = tbeval(rotorder,rotmatrix);
rotmatrix1 = calcrotmatrix(x,y,z,rotorder);
x = num2str(x);
y = num2str(y);
z = num2str(z);
set(handles.x,'string',x);
set(handles.y,'string',y);
set(handles.z,'string',z);
set(handles.rotmatrix1,'data',rotmatrix1);
if((strcmp(x,'NaN')==0)&&(strcmp(y,'NaN')==0)&&(strcmp(z,'NaN')==0))
    set(handles.result,'string','Tait-Bryan angles computed!');
else
    set(handles.result,'string','Tait-Bryan angles could not be computed!');
end



function j1vel_Callback(hObject, eventdata, handles)
% hObject    handle to j1vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j1vel as text
%        str2double(get(hObject,'String')) returns contents of j1vel as a double


% --- Executes during object creation, after setting all properties.
function j1vel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j1vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function j2vel_Callback(hObject, eventdata, handles)
% hObject    handle to j2vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j2vel as text
%        str2double(get(hObject,'String')) returns contents of j2vel as a double


% --- Executes during object creation, after setting all properties.
function j2vel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j2vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function j3vel_Callback(hObject, eventdata, handles)
% hObject    handle to j3vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j3vel as text
%        str2double(get(hObject,'String')) returns contents of j3vel as a double


% --- Executes during object creation, after setting all properties.
function j3vel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j3vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
