function varargout = ik(varargin)
% IK MATLAB code for ik.fig
%      IK, by itself, creates a new IK or raises the existing
%      singleton*.
%
%      H = IK returns the handle to a new IK or the handle to
%      the existing singleton*.
%
%      IK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IK.M with the given input arguments.
%
%      IK('Property','Value',...) creates a new IK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ik_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ik_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ik

% Last Modified by GUIDE v2.5 23-Nov-2016 18:25:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ik_OpeningFcn, ...
                   'gui_OutputFcn',  @ik_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ik is made visible.
function ik_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ik (see VARARGIN)

% Choose default command line output for ik
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ik wait for user response (see UIRESUME)
% uiwait(handles.figure1);
% set both matrices to identity matrix
rotmatrix = [1 0 0 ; 0 1 0 ; 0 0 1];
set(handles.matrix,'data',rotmatrix);
set(handles.transmatrix,'data',rotmatrix);

% --- Outputs from this function are returned to the command line.
function varargout = ik_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in rotorder.
function rotorder_Callback(hObject, eventdata, handles)
% hObject    handle to rotorder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns rotorder contents as cell array
%        contents{get(hObject,'Value')} returns selected item from rotorder


% --- Executes during object creation, after setting all properties.
function rotorder_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rotorder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: rotorder controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editx_Callback(hObject, eventdata, handles)
% hObject    handle to editx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editx as text
%        str2double(get(hObject,'String')) returns contents of editx as a double


% --- Executes during object creation, after setting all properties.
function editx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edity_Callback(hObject, eventdata, handles)
% hObject    handle to edity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edity as text
%        str2double(get(hObject,'String')) returns contents of edity as a double


% --- Executes during object creation, after setting all properties.
function edity_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editz_Callback(hObject, eventdata, handles)
% hObject    handle to editz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editz as text
%        str2double(get(hObject,'String')) returns contents of editz as a double


% --- Executes during object creation, after setting all properties.
function editz_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in rotmatrix.
function rotmatrix_Callback(hObject, eventdata, handles)
% hObject    handle to rotmatrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% get the tait-bryan angles from user input
x = str2double(get(handles.editx,'string'));
y = str2double(get(handles.edity,'string'));
z = str2double(get(handles.editz,'string'));
% get the order of rotation from user input
order = num2str(get(handles.rotorder,'value'));
% calculate rotation matrix
rotmatrix = calcrotmatrix(x,y,z,order);
% display rotation matrix
set(handles.matrix,'data',rotmatrix);
% display result of operation
set(handles.rotmatresult,'string','Rotation matrix created!');

% --- Executes on button press in simulate.
function simulate_Callback(hObject, eventdata, handles)
% hObject    handle to simulate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% get joint angles from GUI data
j1 = get(handles.joint1,'string');
j2 = get(handles.joint2,'string');
j3 = get(handles.joint3,'string');
% get joint velocities from user input
j1vel = get(handles.j1vel,'string');
j2vel = get(handles.j2vel,'string');
j3vel = get(handles.j3vel,'string');
% execute simulation
execute(j1,j2,j3,j1vel,j2vel,j3vel);
guidata(hObject,handles);

% --- Executes on button press in jointangles.
function jointangles_Callback(hObject, eventdata, handles)
% hObject    handle to jointangles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% get tait-bryan angles from user input
x = str2double(get(handles.editx,'string'));
y = str2double(get(handles.edity,'string'));
z = str2double(get(handles.editz,'string'));
% get order of rotation from user input
order = num2str(get(handles.rotorder,'value'));
% calculate rotation matrix
rotmatrix = calcrotmatrix(x,y,z,order);
% compute joint angles using rotation matrix
[j1,j2,j3] = calcjointangles(rotmatrix);
% calculate transformation matrix using joint angles
tramsmatrix = evaltransmatrix(j1,j2,j3);
% display joint angles
set(handles.joint1,'string',num2str(j1));
set(handles.joint2,'string',num2str(j2));
set(handles.joint3,'string',num2str(j3));
% display transformation matrix
set(handles.transmatrix,'data',tramsmatrix);
% check if joint angles exist, and display result
if((strcmp(num2str(j1),'NaN') == 0) && (strcmp(num2str(j2),'NaN') == 0) && (strcmp(num2str(j3),'NaN') == 0))
    set(handles.result,'string','Joint angles computed!');
else
    set(handles.result,'string','Joint angles could not be computed!');
end





% --- Executes on button press in clear.
function clear_Callback(hObject, eventdata, handles)
% hObject    handle to clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.editx,'string','0');
set(handles.edity,'string','0');
set(handles.editz,'string','0');
rotmatrix = [1 0 0 ; 0 1 0 ; 0 0 1];
set(handles.matrix,'data',rotmatrix);



function j1vel_Callback(hObject, eventdata, handles)
% hObject    handle to j1vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j1vel as text
%        str2double(get(hObject,'String')) returns contents of j1vel as a double


% --- Executes during object creation, after setting all properties.
function j1vel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j1vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function j2vel_Callback(hObject, eventdata, handles)
% hObject    handle to j2vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j2vel as text
%        str2double(get(hObject,'String')) returns contents of j2vel as a double


% --- Executes during object creation, after setting all properties.
function j2vel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j2vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function j3vel_Callback(hObject, eventdata, handles)
% hObject    handle to j3vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of j3vel as text
%        str2double(get(hObject,'String')) returns contents of j3vel as a double


% --- Executes during object creation, after setting all properties.
function j3vel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to j3vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
